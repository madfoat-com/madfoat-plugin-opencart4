<?php
// Heading
$_['heading_title']     = 'Thank you for shopping with %s .... ';

// Text
$_['text_title']        = 'Madfoat Payments';
$_['text_response']     = 'Response from Madfoat:';
?>
