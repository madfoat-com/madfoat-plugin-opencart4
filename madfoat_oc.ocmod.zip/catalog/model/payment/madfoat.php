<?php 

namespace Opencart\Catalog\Model\Extension\MadfoatOc\Payment;

class Madfoat extends \Opencart\System\Engine\Model {
	
	// For OC version 4.0.2.0, 4.0.2.1
	public function getMethods(array $address = []): array {
		
		$total = $this->cart->getTotal(); 
		
		$this->load->language('extension/madfoat_oc/payment/madfoat');
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('madfoat_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
		
		if ($this->config->get('madfoat_total') > $total) {
			$status = false;
		} elseif (!$this->config->get('madfoat_geo_zone_id')) {
			$status = true;
		} elseif ($query->num_rows) {
			$status = true;
		} else {
			$status = false;
		}	
		
		$method_data = array();
		$title=trim($this->config->get('madfoat_title'));
		if (empty($title)) {
			$title=trim($this->language->get('text_title'));
			if (empty($title)) {
				$title="Credit Card / Debit Card (Madfoat)";
			}
		}
	
		if ($status) {
			$option_data['madfoat'] = [
				'code' => 'madfoat.madfoat',
				'name' => $title
			];
			$method_data = array( 
				'code'		=> 'madfoat',
				'name'		=> $title,
				'option'     => $option_data,
				'terms' => '',
				'sort_order'	=> $this->config->get('madfoat_sort_order')
			);
		}
		
		
		return $method_data;
	}
	
	// For OC version 4.0.0.0, 4.0.1.0, 4.0.1.1
	public function getMethod(array $address = []): array {
		
		$total = $this->cart->getTotal(); 
		
		$this->load->language('extension/madfoat_oc/payment/madfoat');
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('madfoat_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
		
		if ($this->config->get('madfoat_total') > $total) {
			$status = false;
		} elseif (!$this->config->get('madfoat_geo_zone_id')) {
			$status = true;
		} elseif ($query->num_rows) {
			$status = true;
		} else {
			$status = false;
		}	
		
		$method_data = array();
		$title=trim($this->config->get('madfoat_title'));
		if (empty($title)) {
			$title=trim($this->language->get('text_title'));
			if (empty($title)) {
				$title="Credit Card / Debit Card (Madfoat)";
			}
		}
	
		if ($status) {
			$option_data['madfoat'] = [
				'code' => 'madfoat.madfoat',
				'title' => $title
			];
			$method_data = array( 
				'code'		=> 'madfoat',
				'title'		=> $title,
				'option'     => $option_data,
				'terms' => '',
				'sort_order'	=> $this->config->get('madfoat_sort_order')
			);
		}
		
		
		return $method_data;
	}

}
?>